import { useMemo, useState } from "react";
import { Sparkles, Plus, Folder, Settings, HelpCircle, Send, Monitor, Smartphone, Code2, Eye, ChevronDown, FileCode2, Loader2, Download, PanelLeftClose } from "lucide-react";

const starter = {
  "index.html": `<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Your generated app</title></head><body><div id="root"></div><script type="module" src="/src/App.jsx"></script></body></html>`,
  "src/App.jsx": `export default function App(){return <main className="welcome"><span className="eyebrow">YOUR PROJECT PREVIEW</span><h1>Your next idea<br/>starts here.</h1><p>Describe what you want to build in the MUSA AI Studio prompt panel.</p><button onClick={()=>alert("Your app is ready to customize.")}>Explore project</button></main>}`,
  "src/style.css": `*{box-sizing:border-box}body{margin:0;font-family:Inter,Arial,sans-serif;color:#202a32;background:#f6f5f1}.welcome{min-height:100vh;display:flex;flex-direction:column;justify-content:center;align-items:flex-start;padding:10vw}.eyebrow{letter-spacing:.18em;font-size:11px;color:#a18450}.welcome h1{font-family:Georgia,serif;font-size:clamp(42px,7vw,76px);line-height:1.02;margin:22px 0}.welcome p{color:#69737a;max-width:440px;line-height:1.7}.welcome button{background:#17232c;color:white;border:0;border-radius:7px;padding:14px 22px;margin-top:18px;cursor:pointer}`
};

function buildPreview(files) {
  const html = files["index.html"] || starter["index.html"];
  const jsx = files["src/App.jsx"] || "";
  const css = files["src/style.css"] || "";
  // The preview is intentionally a safe static HTML preview. React JSX is shown in the editor;
  // a generated preview is provided when the model returns a standalone HTML preview in preview.html.
  if (files["preview.html"]) return files["preview.html"];
  const title = (html.match(/<title>(.*?)<\/title>/i) || [,"Generated project"])[1];
  const safeCss = css.replace(/<\/style/gi, "<\\/style");
  const safeTitle = title.replace(/[<&>"]/g, "");
  const fallback = `<div style="max-width:760px;margin:12vh auto;padding:40px;font-family:Arial;color:#202a32"><small style="letter-spacing:.15em;color:#a18450">MUSA AI STUDIO PREVIEW</small><h1 style="font: bold 48px Georgia;margin:20px 0">Your project files are ready.</h1><p style="color:#69737a;line-height:1.7">The generated React source is available in the code panel. To run the full React project, download it and start the development server.</p><pre style="white-space:pre-wrap;background:#f1f0ec;padding:16px;border-radius:8px">${jsx.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").slice(0,1600)}</pre></div>`;
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${safeTitle}</title><style>${safeCss}</style></head><body>${fallback}</body></html>`;
}

export default function App(){
  const [files,setFiles]=useState(starter);
  const [activeFile,setActiveFile]=useState("src/App.jsx");
  const [prompt,setPrompt]=useState("");
  const [messages,setMessages]=useState([{role:"assistant",text:"Welcome to MUSA AI Studio. Describe the website or application you want to create. I’ll generate project files you can edit and export."}]);
  const [busy,setBusy]=useState(false);
  const [mode,setMode]=useState("preview");
  const [device,setDevice]=useState("desktop");
  const [project,setProject]=useState("Untitled project");
  const [notice,setNotice]=useState("");
  const preview=useMemo(()=>buildPreview(files),[files]);

  async function generate(){
    if(!prompt.trim()||busy)return;
    const instruction=prompt.trim();setPrompt("");setMessages(m=>[...m,{role:"user",text:instruction}]);setBusy(true);setNotice("");
    try{
      const r=await fetch("/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt:instruction,currentFiles:files})});
      const data=await r.json();
      if(!r.ok)throw new Error(data.error||"Generation failed.");
      setFiles(prev=>({...prev,...data.files}));setActiveFile(Object.keys(data.files)[0]||"src/App.jsx");
      setMessages(m=>[...m,{role:"assistant",text:data.message||"Project files generated. Review the files and preview."}]);
    }catch(e){setMessages(m=>[...m,{role:"assistant",text:e.message}]);}
    finally{setBusy(false);}
  }
  function downloadProject(){
    const content=Object.entries(files).map(([name,value])=>`===== ${name} =====\n${value}`).join("\n\n");
    const blob=new Blob([content],{type:"text/plain"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="musa-ai-studio-project-files.txt";a.click();URL.revokeObjectURL(url);
  }
  function updateFile(value){setFiles(f=>({...f,[activeFile]:value}));}
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><Sparkles size={17}/></div><div><b>MUSA</b><span>AI STUDIO</span></div></div>
      <button className="new-project" onClick={()=>{setFiles(starter);setMessages([{role:"assistant",text:"New project started. What would you like to build?"}]);setProject("Untitled project");}}> <Plus size={16}/> New project</button>
      <div className="side-label">WORKSPACE</div><button className="side-link active"><Folder size={16}/> Projects</button>
      <div className="side-spacer"/>
      <button className="side-link"><Settings size={16}/> Settings</button><button className="side-link"><HelpCircle size={16}/> Help & support</button>
      <div className="sidebar-foot">Independent workspace<br/>Build thoughtfully. Ship confidently.</div>
    </aside>
    <main className="main">
      <header className="topbar"><div className="crumb">Projects <span>/</span> <input aria-label="Project name" value={project} onChange={e=>setProject(e.target.value)}/><ChevronDown size={14}/></div><div className="top-actions"><span className="status-dot"/> Workspace ready <button className="export" onClick={downloadProject}><Download size={15}/> Export files</button></div></header>
      <section className="workspace">
        <aside className="chat-panel">
          <div className="panel-heading"><div><b>Build with AI</b><small>Describe an idea. Refine it as you go.</small></div><Sparkles size={17}/></div>
          <div className="messages">{messages.map((m,i)=><div className={`message ${m.role}`} key={i}><div className="message-avatar">{m.role==="assistant"?<Sparkles size={14}/>: "You"}</div><div className="message-text">{m.text}</div></div>)}{busy&&<div className="message assistant"><div className="message-avatar"><Sparkles size={14}/></div><div className="message-text"><Loader2 className="spin" size={16}/> Generating project files…</div></div>}</div>
          <div className="prompt-wrap"><textarea value={prompt} onChange={e=>setPrompt(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();generate();}}} placeholder="Describe what you want to build…"/><div className="prompt-bottom"><span>Enter to send · Shift + Enter for new line</span><button disabled={busy||!prompt.trim()} onClick={generate}><Send size={15}/></button></div></div>
          <p className="privacy-note">AI generation requires your own server-side API key.</p>
        </aside>
        <section className="builder-panel">
          <div className="builder-toolbar"><div className="view-tabs"><button className={mode==="preview"?"selected":""} onClick={()=>setMode("preview")}><Eye size={15}/> Preview</button><button className={mode==="code"?"selected":""} onClick={()=>setMode("code")}><Code2 size={15}/> Code</button></div><div className="device-tabs"><button className={device==="desktop"?"selected":""} onClick={()=>setDevice("desktop")}><Monitor size={15}/></button><button className={device==="mobile"?"selected":""} onClick={()=>setDevice("mobile")}><Smartphone size={15}/></button></div></div>
          {mode==="preview"?<div className="preview-stage"><div className={`preview-frame ${device}`}><iframe title="Project preview" sandbox="allow-scripts" srcDoc={preview}/></div></div>:
          <div className="code-workspace"><div className="file-list"><div className="file-list-title">PROJECT FILES</div>{Object.keys(files).map(name=><button key={name} className={activeFile===name?"file-active":""} onClick={()=>setActiveFile(name)}><FileCode2 size={14}/>{name}</button>)}</div><div className="editor"><div className="editor-title">{activeFile}</div><textarea spellCheck="false" value={files[activeFile]||""} onChange={e=>updateFile(e.target.value)}/></div></div>}
        </section>
      </section>
    </main>
  </div>;
}