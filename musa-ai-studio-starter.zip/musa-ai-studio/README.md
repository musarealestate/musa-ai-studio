# MUSA AI Studio

A starter AI website-builder workspace with a prompt chat, editable project files, preview panel, and server-side AI generation endpoint.

## Requirements
- Node.js 18 or newer
- An OpenAI API key (usage may be billed by the provider)

## Run locally
1. Download and extract this project.
2. Open the project folder in a terminal.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Add your API key to `OPENAI_API_KEY` in `.env`.
6. Run `npm run dev`.
7. Open the local URL printed by Vite (usually http://localhost:5173).

## Production
Run `npm run build`, then `npm start`. The Express server serves the built frontend and `/api` endpoints.

## Important limitations in this starter
- AI generation requires a valid server-side API key.
- Generated files are held in browser memory until exported; persistent accounts/database are not implemented yet.
- Export currently downloads a text bundle of project files, not a ZIP.
- The preview panel displays `preview.html` if the model generates one; otherwise it displays a safe source summary. It does not execute arbitrary generated React code in the parent application.
- GitHub OAuth/push, database persistence, team accounts, and one-click deployment are not implemented in this first version.
- GitHub Pages alone cannot host the server-side AI endpoint. Deploy the backend to a Node-capable host and keep secrets there.
- Do not commit `.env` or API keys to GitHub.
