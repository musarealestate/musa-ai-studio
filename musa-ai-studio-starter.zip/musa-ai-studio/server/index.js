import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json({ limit: "2mb" }));
const PORT = process.env.PORT || 8787;

app.get("/api/health", (_req, res) => res.json({ ok: true, aiConfigured: Boolean(process.env.OPENAI_API_KEY) }));

app.post("/api/generate", async (req, res) => {
  const { prompt, currentFiles = {} } = req.body || {};
  if (!prompt || typeof prompt !== "string") return res.status(400).json({ error: "Please enter a project instruction." });
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "AI is not connected yet. Add OPENAI_API_KEY to your server .env file, then restart the server." });

  const system = `You are the code-generation engine for MUSA AI Studio. Generate or update a small, runnable web application.
Return ONLY valid JSON in this exact shape: {"files":{"index.html":"...","src/App.jsx":"...","src/style.css":"..."},"message":"short explanation"}.
Always include index.html, src/App.jsx and src/style.css. Use React JSX in App.jsx and ordinary CSS in style.css. Do not use markdown fences. Make all requested buttons functional where reasonably possible. Preserve and improve existing files supplied by the user. Never claim external integrations work unless credentials and backend routes exist. Do not include secrets.`;
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        temperature: 0.2,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: system },
          { role: "user", content: JSON.stringify({ instruction: prompt, existingFiles: currentFiles }) }
        ]
      })
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data.error?.message || "AI provider request failed." });
    const output = JSON.parse(data.choices?.[0]?.message?.content || "{}");
    if (!output.files || typeof output.files !== "object") throw new Error("The AI response did not contain project files.");
    res.json({ files: output.files, message: output.message || "Project updated." });
  } catch (error) {
    res.status(500).json({ error: error.message || "Generation failed." });
  }
});

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dist = path.join(__dirname, "../dist");
app.use(express.static(dist));
app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(dist, "index.html"), err => err && res.status(404).send("Build the frontend first."));
});
app.listen(PORT, () => console.log(`MUSA AI Studio server running at http://localhost:${PORT}`));